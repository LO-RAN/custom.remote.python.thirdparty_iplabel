from dynatrace.main import Dynatrace
from dynatrace.http_client import TOO_MANY_REQUESTS_WAIT
